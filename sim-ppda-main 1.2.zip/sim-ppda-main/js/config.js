/* js/config.js */

const APP_CONFIG = {
    // GANTI DENGAN URL DEPLOYMENT TERBARU ANDA SETIAP UPDATE!
    API_URL: 'https://script.google.com/macros/s/AKfycbzDE92HOL7KvMU5V9zBqSIuhRX6yCDuj6D3Brgiop6t1YFOCi4j7ymHVU2X1SPDLxt0/exec',
    
    GITHUB_OWNER: 'ppdaalawi',
    GITHUB_REPO: 'sim-ppda'
};
